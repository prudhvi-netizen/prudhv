clear all
clc
FDetect = vision.CascadeObjectDetector;
 [FileName,PathName] = uigetfile('*.jpg;*.png;*.bmp','Pick an Image');
if isequal(FileName,0)||isequal(PathName,0)
    warndlg('user press cancel');
else 
    I=imread([PathName,FileName]);
end
 BB = step(FDetect,I);
  figure,
imshow(I); hold on
for i = 1:size(BB,1)
    rectangle('Position',BB(i,:),'LineWidth',5,'LineStyle','-','EdgeColor','r');
end
title('Face Detection');
hold off;

 NoseDetect = vision.CascadeObjectDetector('Nose','MergeThreshold',16);



BB=step(NoseDetect,I);


figure,
imshow(I); hold on
for i = 1:size(BB,1)
    rectangle('Position',BB(i,:),'LineWidth',4,'LineStyle','-','EdgeColor','b');
end
title('Nose Detection');
hold off;
 MouthDetect = vision.CascadeObjectDetector('Mouth','MergeThreshold',16);

BB=step(MouthDetect,I);


figure,
imshow(I); hold on
for i = 1:size(BB,1)
 rectangle('Position',BB(i,:),'LineWidth',4,'LineStyle','-','EdgeColor','r');
end
title('Mouth Detection');
hold off;
 EyeDetect = vision.CascadeObjectDetector('EyePairBig');
 
